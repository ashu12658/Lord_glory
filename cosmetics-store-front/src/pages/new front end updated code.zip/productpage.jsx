import React, { useEffect, useState } from "react";
import axios from "../utils/axios";
import { jwtDecode } from "jwt-decode";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import productImage from "../assets/product.jpeg";
import styled from "styled-components";
import { 
  FiShoppingCart, 
  FiInfo, 
  FiCheckCircle, 
  FiTruck,
  FiDroplet,
  FiSun
} from "react-icons/fi";
import { FaHandsWash } from "react-icons/fa";

// Mobile-first responsive styling
const PageContainer = styled.div`
  padding: 16px;
  min-height: 100vh;
  background: #f8f9fa;
  display: flex;
  justify-content: center;
  align-items: center;
`;

const ProductCard = styled(motion.div)`
  background: white;
  width: 100%;
  max-width: 1000px;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  display: flex;
  flex-direction: column;

  @media (min-width: 768px) {
    flex-direction: row;
  }
`;

const ProductImageSection = styled.div`
  padding: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  border-bottom: 1px solid #eee;

  @media (min-width: 768px) {
    flex: 1;
    border-bottom: none;
    border-right: 1px solid #eee;
    padding: 30px;
  }
`;

const ProductImage = styled.img`
  width: 100%;
  max-width: 300px;
  height: auto;
  object-fit: contain;
  margin-bottom: 20px;
  border-radius: 8px;
`;

const ProductTitle = styled.h2`
  font-size: 1.5rem;
  color: #333;
  margin-bottom: 8px;
  text-align: center;
`;

const ProductPrice = styled.p`
  font-size: 1.8rem;
  font-weight: bold;
  color: #ff69b4;
  margin-bottom: 20px;
`;

const OrderForm = styled.div`
  width: 100%;
  max-width: 350px;
  padding: 0 10px;

  @media (min-width: 768px) {
    padding: 0;
  }
`;

const InputField = styled.input`
  width: 100%;
  padding: 12px;
  margin-bottom: 12px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 1rem;

  &:focus {
    border-color: #ff69b4;
    outline: none;
  }
`;

const BuyButton = styled.button`
  width: 100%;
  padding: 14px;
  background: linear-gradient(to right, #ff69b4, #ff8c66);
  color: white;
  border: none;
  border-radius: 6px;
  font-size: 1rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  cursor: pointer;
  transition: all 0.2s;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(255, 105, 180, 0.3);
  }

  &:disabled {
    background: #ccc;
    cursor: not-allowed;
    transform: none;
    box-shadow: none;
  }
`;

const ProductDetails = styled.div`
  padding: 20px;
  flex: 1;

  @media (min-width: 768px) {
    padding: 30px;
  }
`;

const SectionTitle = styled.h3`
  font-size: 1.3rem;
  color: #ff69b4;
  margin-bottom: 16px;
  display: flex;
  align-items: center;
  gap: 8px;
`;

const ProductDescription = styled.p`
  color: #555;
  line-height: 1.6;
  margin-bottom: 20px;
`;

const BenefitsList = styled.ul`
  list-style: none;
  padding: 0;
  margin-bottom: 20px;
`;

const BenefitItem = styled.li`
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 10px;
  color: #444;
`;

const UsageSteps = styled.div`
  background: #f9f9f9;
  padding: 16px;
  border-radius: 8px;
  margin-bottom: 20px;
`;

const UsageStep = styled.div`
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
  padding-bottom: 16px;
  border-bottom: 1px dashed #ddd;

  &:last-child {
    margin-bottom: 0;
    padding-bottom: 0;
    border-bottom: none;
  }
`;

const StepNumber = styled.div`
  width: 24px;
  height: 24px;
  background: #ff69b4;
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  font-size: 0.9rem;
`;

const StepContent = styled.div``;

const StepTitle = styled.h4`
  margin: 0 0 4px 0;
  font-size: 1rem;
  display: flex;
  align-items: center;
  gap: 8px;
`;

const StepDescription = styled.p`
  margin: 0;
  color: #666;
  font-size: 0.9rem;
`;

const DeliveryInfo = styled.div`
  background: #f0f8ff;
  padding: 12px;
  border-radius: 6px;
  display: flex;
  align-items: center;
  gap: 8px;
  color: #2c3e50;
`;

const ProductPage = () => {
  const [products, setProducts] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [pincode, setPincode] = useState("");
  const [coupon, setCoupon] = useState("");
  const [processing, setProcessing] = useState(false);
  const navigate = useNavigate();

  const getToken = () => localStorage.getItem("token");

  const isTokenValid = (token) => {
    if (!token) return false;
    try {
      const decoded = jwtDecode(token);
      return decoded?.exp > Date.now() / 1000;
    } catch {
      return false;
    }
  };

  useEffect(() => {
    const fetchProducts = async () => {
      const token = getToken();
      if (!isTokenValid(token)) {
        setError("Session expired. Please log in again.");
        setTimeout(() => navigate("/login"), 1500);
        return;
      }
      try {
        const response = await axios.get("/products", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setProducts(response.data.products || []);
      } catch (err) {
        setError(err.response?.data?.message || "Failed to fetch products.");
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, [navigate]);

  const handleOrder = async (productId, amount) => {
    if (!phone || !address || !pincode) {
      setError("Please fill in all required fields");
      return;
    }

    const token = getToken();
    if (!isTokenValid(token)) {
      setError("Session expired. Please log in again.");
      setTimeout(() => navigate("/login"), 1500);
      return;
    }

    const decodedToken = jwtDecode(token);
    const userId = decodedToken?.id || decodedToken?.userId;

    if (!userId) {
      setError("User authentication failed");
      return;
    }

    setProcessing(true);

    try {
      const response = await axios.post(
        "/payments/phonepe/initiate",
        {
          amount,
          userId,
          phone,
          address,
          pincode,
          couponCode: coupon,
          deliveryTime: "3-5 business days",
          products: [{ productId, quantity: 1 }],
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      if (response.data?.data?.paymentUrl) {
        window.location.href = response.data.data.paymentUrl;
      } else {
        setError("Payment initiation failed");
      }
    } catch (err) {
      setError(err.response?.data?.error || "Payment failed");
    } finally {
      setProcessing(false);
    }
  };

  if (loading) return <div style={{textAlign: 'center', padding: '40px'}}>Loading...</div>;

  if (error) return <div style={{color: 'red', textAlign: 'center', padding: '40px'}}>{error}</div>;

  return (
    <PageContainer>
      {products.length > 0 ? (
        products.map((product) => (
          <ProductCard
            key={product._id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <ProductImageSection>
              <ProductImage
                src={product.image || productImage}
                alt={product.name}
              />
              <ProductTitle>{product.name}</ProductTitle>
              <ProductPrice>₹{product.price}</ProductPrice>

              <OrderForm>
                {error && <div style={{color: 'red', marginBottom: '12px', textAlign: 'center'}}>{error}</div>}

                <InputField
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="Phone Number *"
                  required
                />

                <InputField
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Full Address *"
                  required
                />

                <InputField
                  type="text"
                  value={pincode}
                  onChange={(e) => setPincode(e.target.value)}
                  placeholder="Pincode *"
                  required
                />

                <InputField
                  type="text"
                  value={coupon}
                  onChange={(e) => setCoupon(e.target.value)}
                  placeholder="Coupon Code (Optional)"
                />

                <BuyButton
                  onClick={() => handleOrder(product._id, product.price)}
                  disabled={processing}
                >
                  <FiShoppingCart />
                  {processing ? "Processing..." : "Buy Now"}
                </BuyButton>
              </OrderForm>
            </ProductImageSection>

            <ProductDetails>
              <SectionTitle>
                <FiInfo /> Product Details
              </SectionTitle>
              <ProductDescription>
                Our premium 3-step skincare system includes a gentle cleanser, 
                hydrating serum, and protective sunscreen for complete daily care.
              </ProductDescription>

              <UsageSteps>
                <UsageStep>
                  <StepNumber>1</StepNumber>
                  <StepContent>
                    <StepTitle>
                      <FaHandsWash /> Cleanse
                    </StepTitle>
                    <StepDescription>
                      Gently wash your face with our pH-balanced cleanser.
                    </StepDescription>
                  </StepContent>
                </UsageStep>

                <UsageStep>
                  <StepNumber>2</StepNumber>
                  <StepContent>
                    <StepTitle>
                      <FiDroplet /> Treat
                    </StepTitle>
                    <StepDescription>
                      Apply serum to hydrate and nourish your skin.
                    </StepDescription>
                  </StepContent>
                </UsageStep>

                <UsageStep>
                  <StepNumber>3</StepNumber>
                  <StepContent>
                    <StepTitle>
                      <FiSun /> Protect
                    </StepTitle>
                    <StepDescription>
                      Finish with sunscreen to shield from UV damage.
                    </StepDescription>
                  </StepContent>
                </UsageStep>
              </UsageSteps>

              <SectionTitle>
                <FiCheckCircle /> Benefits
              </SectionTitle>
              <BenefitsList>
                <BenefitItem>
                  <FiCheckCircle color="#ff69b4" /> Reduces acne and breakouts
                </BenefitItem>
                <BenefitItem>
                  <FiCheckCircle color="#ff69b4" /> Deep hydration
                </BenefitItem>
                <BenefitItem>
                  <FiCheckCircle color="#ff69b4" /> SPF 50 protection
                </BenefitItem>
              </BenefitsList>

              <DeliveryInfo>
                <FiTruck /> Free delivery in 3-5 business days
              </DeliveryInfo>
            </ProductDetails>
          </ProductCard>
        ))
      ) : (
        <div style={{textAlign: 'center', padding: '40px'}}>
          No products available
        </div>
      )}
    </PageContainer>
  );
};

export default ProductPage;