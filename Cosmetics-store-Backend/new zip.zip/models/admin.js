const express = require("express");
const router = express.Router();
const { registerAdmin, loginAdmin } = require("../controllers/admincontroller");

router.post("/register", registerAdmin); // Admin registration
router.post("/login", loginAdmin); // Admin login

module.exports = router;
